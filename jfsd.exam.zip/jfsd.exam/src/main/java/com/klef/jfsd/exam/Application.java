package com.klef.jfsd.exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = "com.klef.jfsd.exam")
@EnableJpaRepositories(basePackages = "com.klef.jfsd.exam.repository")
@EntityScan(basePackages = "com.klef.jfsd.exam.model")   // Specify your base package here
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}
